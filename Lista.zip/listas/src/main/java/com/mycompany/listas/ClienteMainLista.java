
package com.mycompany.listas;

public class ClienteMainLista {
    public static void main(String[] args) {
        try {
            Lista<Integer> lista = new Lista<Integer>();
            
            lista.agregar(12);
            lista.agregar(15);
            lista.agregar(20);

            System.out.println("Datos del elemento 0:"+lista.getValor(0));
            System.out.println("Datos del elemento 1:"+lista.getValor(1));
            System.out.println("Datos del elemento 2:"+lista.getValor(2));

            lista.insertar(16, 0);
            lista.insertar(15, 1);
            lista.insertar(13, 2);
            
            System.out.println("Datos del elemento 0:"+lista.getValor(0));
            System.out.println("Datos del elemento 1:"+lista.getValor(1));
            System.out.println("Datos del elemento 2:"+lista.getValor(2));
            
            lista.remover(0);
            lista.remover(3);
            
            System.out.println("Valores despues de remover");
            System.out.println("Datos del elemento 0:"+lista.getValor(0));
            System.out.println("Datos del elemento 1:"+lista.getValor(1));
            System.out.println("Datos del elemento 2:"+lista.getValor(2));
            
        } catch ( PosicionIlegalException e) {
        e.printStackTrace();;
        }
    }
}
