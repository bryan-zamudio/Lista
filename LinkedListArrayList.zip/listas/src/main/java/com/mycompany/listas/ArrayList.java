package com.mycompany.listas;

import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;

public class ArrayList {
    public static void main(String[] args) {
        try{
            List<Integer> list =new LinkedList<Integer>();
            list.add(12);
            list.add(15);
            list.add(21);
            System.out.println("Elemento 0: "+list.get(0));
            System.out.println("Elemento 1: "+list.get(1));
            System.out.println("Elemento 2: "+list.get(2));
            list.add(1,13);
            list.add(3,16);
            System.out.println("");
            System.out.println("Después de la Inserción");
            System.out.println("Elemento 0: "+list.get(0));
            System.out.println("Elemento 1: "+list.get(1));
            System.out.println("Elemento 2: "+list.get(2));
            System.out.println("Elemento 3: "+list.get(3));
            System.out.println("Elemento 4: "+list.get(4));
            
            for(int i=0;i<list.size();i++){
                System.out.println("Elemento "+i+":"+list.get(i));
            }
            System.out.println("Recorreo la lista utilizando iterador: ");
            System.out.println("");
            for(Integer elm:list){
                System.out.println(elm);
            }
            list.remove(0);
            list.remove(3);
            
            System.out.println("Recorreo despues de eliminar el primero y último: ");
            System.out.println("");
            for(Integer elm:list){
                System.out.println(elm);
            }
            
            list.set(0, 100);
            System.out.println("Recorreo después de reemplazar el pimero por 100: ");
            System.out.println("");
            for(Integer elm:list){
                System.out.println(elm);
            }
            
            List<Integer> lista2 = new ArrayList<Integer>();
            lista2.add(12);
            lista2.add(15);
            lista2.add(21);
            System.out.println("Elemento 0: "+lista2.get(0));
            System.out.println("Elemento 1: "+lista2.get(1));
            System.out.println("Elemento 2: "+lista2.get(2));
            lista2.add(1,13);
            lista2.add(3,16);
            
            for(int i=0;i<lista2.size();i++){
                System.out.println("Elemento"+i+":"+lista2.get(i));
            }
            lista2.remove(0);
            lista2.remove(3);
            System.out.println("Recorreo después de eliminar el primero y último");
            for(Integer elm:lista2){
                System.out.println(elm);
            }
            lista2.set(0,100);
            for(Integer elm:lista2){
                System.out.println(elm);
            }
        }
        
        
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
