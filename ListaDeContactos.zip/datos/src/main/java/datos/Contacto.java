package datos;

public class Contacto {
    //Atributos
    
    private String nombres;
    private String apellidos;
    private String dirección;
    private String correo;
    private String telefono;
    private String celular;
    
    //Métodos
    //Constructor parametrizado
    public Contacto(){
        
    }

    public Contacto(String nombres, String apellidos, String dirección, String correo, String telefono, String celular) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dirección = dirección;
        this.correo = correo;
        this.telefono = telefono;
        this.celular = celular;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDirección() {
        return dirección;
    }

    public void setDirección(String dirección) {
        this.dirección = dirección;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    
    
}
