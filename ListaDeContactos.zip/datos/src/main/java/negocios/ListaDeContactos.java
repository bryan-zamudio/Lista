package negocios;
import datos.Contacto;
import datos.Lista;
import datos.PosicionIlegalException;

public class ListaDeContactos {
    //Atributo
    private Lista<Contacto> contactos;
    //Método
    public ListaDeContactos(){
        contactos = new Lista<Contacto>();
    }
    public Lista<Contacto> mostrarTodosLosContactos(){
        try{
            for(int i=0;i<contactos.getTamanio();i++){
                System.out.println(contactos.getValor(i).getNombres()+" "+contactos.getValor(i).getApellidos()+" "+
                        contactos.getValor(i).getDirección()+" "+contactos.getValor(i).getCelular());
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return contactos;
    }
    
    public boolean agregarContacto(String nombres, String apellidos, String direccion, String correo,
            String telefono, String celular) throws PosicionIlegalException{
        Contacto con = buscarContacto(nombres,apellidos);
        if(con == null){
            Contacto nuevo = new Contacto(nombres, apellidos, direccion, correo, telefono, celular);
            contactos.agregar(nuevo);
            return true;
        }
        else{
            return false;
        }
    }
    
    public Contacto buscarContacto(String nombres, String apellidos)throws PosicionIlegalException{
        for(int i=0;i<contactos.getTamanio();i++){
        Contacto con = contactos.getValor(i);
        if(nombres.equals(con.getNombres()) && apellidos.equals(con.getNombres())){
            return con;
        }
    }
        return null; //No lo encontró
    }
    
    public boolean eliminarContacto(String nombres, String apellidos)throws PosicionIlegalException{
        Contacto con = buscarContacto(nombres, apellidos);
        if (con != null){
            for(int i=0;i<contactos.getTamanio();i++){
                Contacto contAux = contactos.getValor(i);
                if(contAux.getNombres().equals(nombres) && contAux.getApellidos().equals(apellidos)){
                    contactos.remover(i);
                }
            }
            return true;
        }
        else{
            return false;
        }
    }
}
